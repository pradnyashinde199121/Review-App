import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor(private http:HttpClient) { 
  }
  url='assets/data.json';
  urlContact='assets/contact.json';
  getHotels():Observable<any>{
    return this.http.get<any>(this.url);
  }
  getContacts():Observable<any>{
    return this.http.get<any>(this.urlContact);
  }
}
