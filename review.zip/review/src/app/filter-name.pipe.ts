import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterName'
})
export class FilterNamePipe implements PipeTransform {

  transform(hotels:any, searchTerm:string): any {
    if (!hotels || !searchTerm) {
      return hotels;
  }

  return hotels.filter(hotel =>
    hotel.title.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1);
}
  }