import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReviewComponent } from './review/review.component';
import {MyserviceService} from './myservice.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { PickerModule } from '@ctrl/ngx-emoji-mart'
import { EmojiModule } from '@ctrl/ngx-emoji-mart/ngx-emoji'
import {MatIconModule} from '@angular/material/icon';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {StarRatingModule} from 'angular-star-rating';

import { FilterNamePipe } from './filter-name.pipe';
import { LoginComponent } from './login/login.component';
@NgModule({
  declarations: [
    AppComponent,
    ReviewComponent,
    FilterNamePipe,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,HttpClientModule,
    PickerModule,
    EmojiModule,
    MatIconModule,
    BrowserAnimationsModule,
    StarRatingModule.forRoot(),
  
  ],
  providers: [MyserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
