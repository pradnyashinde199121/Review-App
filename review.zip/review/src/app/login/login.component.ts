import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
   public minDate: Date;
   public minDate1: Date;
   date : any;
   
  //selectedCountry:any={'name':'--Select--','id':'0'};
  constructor() {
    const currentYear = new Date().getFullYear();
    this.minDate = new Date();
    this.minDate1 =new Date();
   }
  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }
  password(event: any) {
    const pattern = "(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}";

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.indexOf(inputChar)) {
      event.preventDefault();
    }
  }
  ngOnInit() {
   }
  changedate(){
    this.minDate1 = this.date; 
  }

  
}
