import { Component, OnInit } from '@angular/core';
import {MyserviceService} from '../myservice.service';
@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {
  hotels:any=[];
  contacts:any=[];
  sendMsgs:any=[];
  sendImgs:any=[];
  searchTerm: string;
  currentTitle:string;
  currentType: string;
  currentdescription:string; 
  currentFamilyType: string;
  currentrating: number;
  cutrrentImg: any;
  currentContact:any={};
  startfalg:boolean=false;
  flag1:boolean=false;
  flag2:boolean=false;
  flag3:boolean=false;
  flag4:boolean=false;
  flag5:boolean=false;
  name = 'Angular';
  message = '';
  showEmojiPicker = false;
  sets = [
    'native',
    'google',
    'twitter',
    'facebook',
    'emojione',
    'apple',
    'messenger'
  ]
  set = 'twitter';
  constructor(private hotelservice:MyserviceService) { }
  
  ngOnInit() {
    this.hotelservice.getHotels().subscribe(x=>{this.hotels=x});
    this.hotelservice.getContacts().subscribe(x=>{this.contacts=x});
    
  }
 
  toggleEmojiPicker() {
    console.log(this.showEmojiPicker);
        this.showEmojiPicker = !this.showEmojiPicker;
  }

  addEmoji(event) {
    console.log(this.message)
    const { message } = this;
    console.log(message);
    console.log(`${event.emoji.native}`)
    const text = `${message}${event.emoji.native}`;

    this.message = text;
    // this.showEmojiPicker = false;
  }

  onFocus() {
    console.log('focus');
    this.showEmojiPicker = false;
  }
  onBlur() {
    console.log('onblur')
  }
  sendMsg(){
    this.sendMsgs.push(this.message);
    this.message='';
  }
  hotelDetail(hotel){
  this.sendMsgs=[];
  this.currentTitle=hotel.title;
  this.currentFamilyType=hotel.FamilyType;
  this.currentdescription=hotel.description;
  this.currentrating=hotel.rating;
  this.cutrrentImg = hotel.img;

  this.startfalg=true;
  this.flag1=false;
  this.flag2=false;
  this.flag3=false;
  this.flag4=false;
  this.flag5=false;
  if(this.currentrating >=1){
    this.flag1=true;
  }
  if(this.currentrating >=2){
    this.flag2=true;
  }
  if(this.currentrating >=3){
    this.flag3=true;
  }
  if(this.currentrating >=4){
    this.flag4=true;
  }
  if(this.currentrating >=5){
    this.flag5=true;
  }
  
  }
  CurrentContact(contact){
   this.currentContact={};
    this.currentContact.Name=contact.name;
    this.currentContact.Img =contact.CustomerImg;
    this.sendImgs.push(this.currentContact);
  
  }

}
